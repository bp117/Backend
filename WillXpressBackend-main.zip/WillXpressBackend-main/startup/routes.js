const express = require('express');

const customerRoutes = require('../routes/customer')
const accountRoutes = require('../routes/account')
const beneficiaryRoutes = require('../routes/beneficiary')
const assetRoutes = require('../routes/asset')
const masterRoutes = require('../routes/master')

const morganMiddleware = require("../middleware/morgan");

module.exports = function (app) {
    app.use(express.json());
    app.use(morganMiddleware);
    app.use('/customer/', customerRoutes);
    app.use('/account/', accountRoutes)
    app.use('/beneficiary/', beneficiaryRoutes)
    app.use('/asset/', assetRoutes)
    app.use('/admin/',masterRoutes)
};
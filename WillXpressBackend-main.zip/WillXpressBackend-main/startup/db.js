const mongoose = require('mongoose');

const dbUri = process.env.MONGODB_URI

const Logger = require('../lib/logger')

const connectDB = async () => {
	try {
		Logger.info('MongoDB Connected...')

		return await mongoose.connect(dbUri, {
			useNewUrlParser: true,
			useUnifiedTopology: true
		});

	} catch (err) {
		Logger.error(err.message);
		// Exit process with failure
		process.exit(1);
	}
};

module.exports = connectDB;
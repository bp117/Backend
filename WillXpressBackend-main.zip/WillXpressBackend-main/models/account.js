const mongoose = require("mongoose");

const AccountSchema = new mongoose.Schema({
    customer:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "customer",
    },
    AccountNumber: {
        type: String,
        required: true
    },
    AccountType: {
        type: String,
        required: true
    },
    Balance: {
        type: Number
    },
    StatusOfAccount: {
        type: String,
        default: 'inactive',
        enum: ['active', 'inactive'],
    },
    allocations: [{ type: mongoose.Schema.Types.ObjectId, ref: "account_allocation" }],
});

const Account = mongoose.model("account", AccountSchema);

// middleware to remove account entries from customers when they get deleted
AccountSchema.pre('deleteOne', { document: true }, function (next) {
    var account = this;

    account.model('customer').update(
        { accounts: account._id },
        { $pull: { accounts: account._id } },
        { multi: true },
        next);
})

module.exports = Account;
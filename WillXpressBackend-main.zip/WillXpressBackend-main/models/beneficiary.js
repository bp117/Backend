const mongoose = require("mongoose");

const BeneficiarySchema = new mongoose.Schema({
  BeneficiaryType: {
    type: String,
    required: true
  },
  relationship: {
    type: String,
    required: true
  },
  BeneficiaryName: {
    type: String,
    required: true
  },
  BeneficiaryAge: {
    type: Number,
  },
  BeneficiaryIdType: {
    type: String,
  },
  BeneficiaryUpdatedDate: {
    type: String,
  },
  IsMinor: {
    type: Boolean,
  },
  GuardianDetails: {
    type: {},
  },
  customer:{
    type: mongoose.Schema.Types.ObjectId,
    ref: "customer",
},
});

const Beneficiary = mongoose.model("beneficiary", BeneficiarySchema);

BeneficiarySchema.pre('deleteOne', { document: true }, function (next) {
  var beneficiary = this;

  beneficiary.model('customer').update(
      { beneficiaries: beneficiary._id },
      { $pull: { beneficiaries: beneficiary._id } },
      { multi: true },
      next);
})

module.exports = Beneficiary;
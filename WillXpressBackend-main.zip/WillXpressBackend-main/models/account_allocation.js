const mongoose = require("mongoose");

const AccountAllocateSchema = new mongoose.Schema({
    account:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "account",
    },
    beneficiary:{
        type: mongoose.Schema.Types.ObjectId,
        ref: "beneficiary",
    },
    percentage:{
        type: Number
    }
});

const AccountAllocation = mongoose.model("account_allocation", AccountAllocateSchema);

// middleware to remove allocation entries from accounts when they get deleted
AccountAllocateSchema.pre('deleteOne', { document: true }, function (next) {
    var accountAllocation = this;

    accountAllocation.model('account').update(
        { allocations: accountAllocation._id },
        { $pull: { allocations: accountAllocation._id } },
        { multi: true },
        next);
})

module.exports = AccountAllocation;
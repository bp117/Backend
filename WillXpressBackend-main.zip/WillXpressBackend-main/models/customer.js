const mongoose = require("mongoose");

const CustomerSchema = new mongoose.Schema({
  ECN: {
    type: String,
    required: true,
    unique: true
  },
  password: {
    type: String,
    required: true,
  },
  CustomerName: {
    type: String,
    required:true
  },
  Address: {
    type: String,
  },
  CustomerAge: {
    type: String,
  },
  accounts: [{ type: mongoose.Schema.Types.ObjectId, ref: "account" }],
  beneficiaries: [{ type: mongoose.Schema.Types.ObjectId, ref: "beneficiary" }],
  assets: [{ type: mongoose.Schema.Types.ObjectId, ref: "asset" }],
});

const Customer = mongoose.model("customer", CustomerSchema);

module.exports = Customer;
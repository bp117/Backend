const mongoose = require("mongoose");

const AssetSchema = new mongoose.Schema({
  AssetName: {
    type: String,
    required: true
  },
  TypeOfAsset: {
    type: String,
    required: true
  },
  MonetaryValue: {
    type: Number,
    required: true
  },
  OtherDetails:{
    type:String
  },
  beneficiary:{
    type: mongoose.Schema.Types.ObjectId,
    ref: "beneficiary",
},
customer:{
    type: mongoose.Schema.Types.ObjectId,
    ref: "customer",
},
});

const Asset = mongoose.model("asset", AssetSchema);


AssetSchema.pre('deleteOne', { document: true }, function (next) {
    var asset = this;

    asset.model('customer').update(
        { assets: asset._id },
        { $pull: { assets: asset._id } },
        { multi: true },
        next);
})

module.exports = Asset;
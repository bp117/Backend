const express = require('express');
const router = express.Router();

const addAccount = require('./addAccount')
const removeAccount = require('./removeAccount')

router.use('/new', addAccount)
router.use('/', removeAccount)


module.exports = router;
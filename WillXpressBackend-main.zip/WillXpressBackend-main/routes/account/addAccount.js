const express = require('express');
const router = express.Router();

const Customer = require('../../models/customer')
const Account = require('../../models/account')
const isLoggedIn = require('../../middleware/isLoggedin')

const { check, validationResult } = require("express-validator");

router.post("/",
    isLoggedIn,
    check("accountNumber", "Account Number is required").notEmpty(),
    check("accountType", "Account Type is required").notEmpty(),
    check("balance", "Balance is required").notEmpty(),
    check("status", "Status of Account is required").notEmpty(),
    async (req, res, next) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ success: false, errors: errors.array() });
            }

            const {
                accountNumber,
                accountType,
                balance,
                status,
            } = req.body

            const customer = await Customer.findById(req.user.id);

            if (!customer) {
                return res.status(400).json({
                    success: false,
                    message: "User does not exist",
                });
            }

            const account = new Account({
                customer: customer?._id,
                AccountNumber: accountNumber,
                AccountType: accountType,
                Balance: balance,
                StatusOfAccount: status
            })

            customer.accounts.push(account?._id)

            await customer.save()
            await account.save();

            return res.send({
                success: true,
                message: 'Account Added successfully',
                data: account
            })


        }
        catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }

    })

module.exports = router;
const express = require('express');
const router = express.Router();

const Customer = require('../../models/customer')
const Asset = require('../../models/asset')
const isLoggedIn = require('../../middleware/isLoggedin')

const { check, validationResult } = require("express-validator");

router.post("/",
    isLoggedIn,
    check("beneficiaryId", "Beneficiary ID is required").notEmpty(),
    check("assetName", "Asset Name is required").notEmpty(),
    check("assetType", "Asset Type is required").notEmpty(),
    check("monetaryValue", "Monetary Value is required").notEmpty(),
    check("otherDetails", "Other Details is required").notEmpty(),
    async (req, res, next) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ success: false, errors: errors.array() });
            }

            const {
                beneficiaryId,
                assetName,
                assetType,
                monetaryValue,
                otherDetails
            } = req.body

            const customer = await Customer.findById(req.user.id);

            if (!customer) {
                return res.status(400).json({
                    success: false,
                    message: "User does not exist",
                });
            }

            const asset = new Asset({
                beneficiary: beneficiaryId,
                AssetName: assetName,
                TypeOfAsset: assetType,
                MonetaryValue: monetaryValue,
                OtherDetails: otherDetails
            })
 customer.assets.push(asset?._id)

            await customer.save()
            await asset.save();

            return res.send({
                success: true,
                message: 'Asset Added successfully',
                data: asset
            })


        }
        catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }

    })

module.exports = router;
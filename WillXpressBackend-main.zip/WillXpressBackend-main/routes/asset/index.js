const express = require('express');
const router = express.Router();

const addAsset = require('./addAsset')
const removeAsset = require('./removeAsset')

router.use('/new', addAsset)
router.use('/', removeAsset)


module.exports = router;
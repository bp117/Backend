const express = require('express');
const router = express.Router();

const Customer = require('../../models/customer')
const Beneficiary = require('../../models/beneficiary')
const isLoggedIn = require('../../middleware/isLoggedin')

const { check, validationResult } = require("express-validator");

router.delete("/",
    isLoggedIn,
    check("beneficiaryId", "Beneficiary Id is required").notEmpty(),
    async (req, res, next) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ success: false, errors: errors.array() });
            }

            const {
                beneficiaryId
            } = req.body

            const customer = await Customer.findById(req.user.id);

            if (!customer) {
                return res.status(400).json({
                    success: false,
                    message: "User does not exist",
                });
            }

            const beneficiary = Beneficiary.findById(beneficiaryId)

            await beneficiary.deleteOne()

            return res.send({
                success: true,
                message: 'Beneficiary deleted successfully',
            })


        }
        catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }

    })

module.exports = router;
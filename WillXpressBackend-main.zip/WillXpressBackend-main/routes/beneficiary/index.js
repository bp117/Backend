const express = require('express');
const router = express.Router();

const addBeneficiary = require('./addBeneficiary')
const removeBeneficiary = require('./removeBeneficiary')

router.use('/new', addBeneficiary)
router.use('/', removeBeneficiary)

module.exports = router;
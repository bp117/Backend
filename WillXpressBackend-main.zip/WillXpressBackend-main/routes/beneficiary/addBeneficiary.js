const express = require('express');
const router = express.Router();

const Customer = require('../../models/customer')
const Beneficiary = require('../../models/beneficiary')

const isLoggedIn = require('../../middleware/isLoggedin')

const { check, validationResult } = require("express-validator");

router.post("/",
    isLoggedIn,
    check("beneficiaryType", "Beneficiary Type is required").notEmpty(),
    check("relationship", "Relationship is required").notEmpty(),
    check("beneficiaryName", "Beneficiary name is required").notEmpty(),
    check("beneficiaryAge", "Beneficiary Age is required").notEmpty(),
    check("beneficiaryIdType", "Id Type is required").notEmpty(),
    check("beneficiaryIdNo", "Id No is required").notEmpty(),
    check("isMinor", "Is Minor is required").notEmpty(),
    async (req, res, next) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ success: false, errors: errors.array() });
            }

            const {
                beneficiaryType,
                relationship,
                beneficiaryName,
                beneficiaryAge,
                beneficiaryIdType,
                beneficiaryIdNo,
                isMinor,
                guardianDetails
            } = req.body

            const customer = await Customer.findById(req.user.id);

            if (!customer) {
                return res.status(400).json({
                    success: false,
                    message: "User does not exist",
                });
            }

            const beneficiary = new Beneficiary({
                customer: customer?._id,
                BeneficiaryType: beneficiaryType,
                relationship,
                BeneficiaryName: beneficiaryName,
                BeneficiaryAge: beneficiaryAge,
                BeneficiaryIdType: beneficiaryIdType,
                GuardianDetails: guardianDetails,
                isMinor,
            })
            customer.beneficiaries.push(beneficiary?._id)

            await customer.save()
            await beneficiary.save();

            return res.send({
                success: true,
                message: 'Beneficiary Added successfully',
                data: beneficiary
            })


        }
        catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }

    })

module.exports = router;
const express = require('express');
const router = express.Router();


const Customer = require('../models/customer')

router.get(
    '/get-all',
    async (req, res) => {
        try {
            const customers = await Customer.find({})
                .populate('beneficiaries')
                .populate('accounts')
                .populate('assets')

            res.status(200).json({
                success:true,
                data: customers
            });

        } catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }
    })


module.exports = router;
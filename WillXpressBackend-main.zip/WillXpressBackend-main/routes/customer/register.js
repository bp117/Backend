const express = require('express');
const router = express.Router();

const bcrypt = require('bcryptjs');
const Customer = require('../../models/customer')

const { check, validationResult } = require("express-validator");

router.post("/",
    check("name", "Name is required").notEmpty(),
    check("age", "Age is required").notEmpty(),
    check("ecn", "ECN is required").notEmpty(),
    check("address", "Address is required").notEmpty(),
    check("password", "Password is required").notEmpty(),
    async (req, res, next) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ success: false, errors: errors.array() });
            }

            const {
                name,
                age,
                ecn,
                address,
                password
            } = req.body

            let existing = await Customer.findOne({ECN:ecn})
            console.log('existing ',existing)
            if(existing){
                return res.status(400).send({
                    message:'Customer with this ECN already exists'
                })
            }

            const customer = new Customer({
                ECN: ecn,
                CustomerName: name,
                Address: address,
                CustomerAge: age,
            })

            const salt = await bcrypt.genSalt(10);

            customer.password = await bcrypt.hash(password, salt);

            await customer.save()

            return res.status(200).json({
                success: true,
                message: "Customer successfully registered",
            })
        }
        catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }

    })


module.exports = router;
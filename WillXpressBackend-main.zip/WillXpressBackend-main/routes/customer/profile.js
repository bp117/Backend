const express = require('express');
const router = express.Router();

const isLoggedIn = require('../../middleware/isLoggedin')

const Customer = require('../../models/customer')
const { check, validationResult } = require('express-validator');

router.get(
    '/',
    isLoggedIn,
    async (req, res) => {
        try {
            const customer = await Customer.findById(req.user.id)
                .populate('beneficiaries')
                .populate('accounts')
                .populate('assets')

            if (!customer) {
                return res.status(400).json({
                    success: false,
                    message: "Customer does not exist",
                });
            }

            res.status(200).json({
                success: true,
                message: "successfully loaded customer's profile",
                profile: customer,
            });

        } catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }
    })

router.post(
    '/by-ecn',
    check('ecn', 'ECN not submitted').isEmail(),
    async (req, res) => {
        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ errors: errors.array() });
            }

            const ecn = req.body.ecn
            const customer = await Customer.find({
                ECN: ecn
            })
                .populate('beneficiaries')
                .populate('accounts')

            if (!customer) {
                return res.status(400).json({
                    success: false,
                    message: "User does not exist",
                });
            }

            res.status(200).json({
                success: true,
                message: "successfully loaded merchant's profile",
                profile: customer,
            });

        } catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }
    })

module.exports = router;
const express = require('express');
const router = express.Router();

const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

const Customer = require('../../models/customer')

const { check, validationResult } = require('express-validator');

router.post(
    '/',
    check('ecn', 'ECN not submitted').notEmpty(),
    check('password', 'Password is required').notEmpty(),
    async (req, res) => {

        try {
            const errors = validationResult(req);
            if (!errors.isEmpty()) {
                return res.status(400).json({ errors: errors.array() });
            }

            const { ecn, password } = req.body;

            let customer = await Customer.findOne({
                ECN: ecn
            })

            if (!customer) {
                return res
                    .status(400)
                    .json({ errors: [{ message: 'Invalid Credentials' }] });
            }

            const isMatch = await bcrypt.compare(password, customer.password);

            // Check user credentials
            if (!isMatch) {
                return res
                    .status(400)
                    .json({ errors: [{ message: 'Invalid Credentials' }] });
            }

            const payload = {
                user: {
                    id: customer.id
                }
            };

            const token = jwt.sign(payload, process.env.JWT_SECRET, { expiresIn: '1 day' })
            const refreshToken = jwt.sign(payload, process.env.JWT_REFRESH_SECRET, { expiresIn: '30 days' });

            if (token && refreshToken) {
                return res.status(200).json({
                    message: "User login successful",
                    token,
                    refreshToken,
                    customer,
                });

            } else {
                return res.status(400).json({
                    error: "Error occured while signing token",
                });
            }

        }
        catch (err) {
            res.status(500).send({
                error: "Internal Server error",
                message: err?.message,
                detail: err.message || err,
            });
        }
    })


module.exports = router;
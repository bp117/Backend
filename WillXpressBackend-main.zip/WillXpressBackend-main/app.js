require('dotenv').config();
const Logger = require('./lib/logger');

const express = require('express');
const app = express();

try {
    require('./startup/db')()
    require('./startup/routes')(app);

    const PORT = process.env.PORT || 5000;
    app.listen(PORT, '0.0.0.0', () => {
        Logger.info(`WillXpress server listening on port ${PORT}`);
    });
} catch (err) {
    console.log('error', err);
    Logger.error(err);
}
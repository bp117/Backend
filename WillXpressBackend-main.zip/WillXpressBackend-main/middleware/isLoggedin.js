const jwt = require('jsonwebtoken');

const Logger = require('../lib/logger')

module.exports = function (req, res, next) {
    // Get token from header
    const token = req.headers['x-access-token'];

    // Check if not token
    if (!token) {
        return res.status(401).json({ message: 'No token, authorization denied' });
    }

    // Verify token
    try {
        jwt.verify(token, process.env.JWT_SECRET, (error, decoded) => {
            if (error) {
                Logger.error(error?.message);

                if (error?.message?.includes('jwt expired')) {
                    return res.status(401).json({ message: 'jwt expired' });
                };

                return res.status(401).json({ message: 'User token is not valid' });
            } else {
                req.user = decoded.user;
                next();
            }
        });
    } catch (err) {
        Logger.error(err.message)
        res.status(500).json({ message: 'Server Error' });
    }
};